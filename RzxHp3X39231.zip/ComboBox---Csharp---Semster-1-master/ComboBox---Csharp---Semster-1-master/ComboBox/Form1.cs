﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ComboBox
{
    public partial class SelectionSwitchStatement : Form
    {
        public SelectionSwitchStatement()
        {
            InitializeComponent();
        }

        //Select Knife Model CT
        private void cboCountries_SelectedIndexChanged(object sender, EventArgs e)
        {
            string knifemodelct = cboCountries.Text;
            switch (knifemodelct)
            {
                case "Bayonet":
                    txtDisplay.Text = "Bayonet";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_bayonet.515de291204d6d896724d9fbb6856fcc6054a787.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    using (var client = new WebClient())
                    {
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct.ani", @"C:\Windows\Temp\v_knife_default_ct.ani");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct.dx90.vtx", @"C:\Windows\Temp\v_knife_default_ct.dx90.vtx");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct.mdl", @"C:\Windows\Temp\v_knife_default_ct.mdl");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct.vvd", @"C:\Windows\Temp\v_knife_default_ct.vvd");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct_anim.ani", @"C:\Windows\Temp\v_knife_default_ct_anim.ani");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct_anim.mdl", @"C:\Windows\Temp\v_knife_default_ct_anim.mdl");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct_inspect.dx90.vtx", @"C:\Windows\Temp\v_knife_default_ct_inspect.dx90.vtx");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct_inspect.mdl", @"C:\Windows\Temp\v_knife_default_ct_inspect.mdl");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bayonet/Lado%20CT/v_knife_default_ct_inspect.vvd", @"C:\Windows\Temp\v_knife_default_ct_inspect.vvd");
                    }
                    //Mover Arquivo para diretório
                    /*File.Move(@"C:\Windows\Temp\v_knife_default_ct.ani", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct.dx90.vtx", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct.mdl", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct.vvd", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct_anim.ani", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct_anim.mdl", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct_inspect.dx90.vtx", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct_inspect.mdl", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        File.Move(@"C:\Windows\Temp\v_knife_default_ct_inspect.vvd", @"F:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\models\weapons");
                        */
                    // Iniciar CMD
                    //System.Diagnostics.Process.Start(@"C:\Windows\Temp\crkofc.bat");
                    break;
case "Bowie Knife":
                    txtDisplay.Text = "Bowie Knife";
                    pictureBox1.LoadAsync("https://steamuserimages-a.akamaihd.net/ugc/934939061706979025/D50F081FA7517CDD7EE8FBAE2C1A9EC372722D05/");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    using (var client = new WebClient())
                    {
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct.ani", @"C:\Windows\Temp\v_knife_default_ct.ani");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct.dx90.vtx", @"C:\Windows\Temp\v_knife_default_ct.dx90.vtx");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct.mdl", @"C:\Windows\Temp\v_knife_default_ct.mdl");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct.vvd", @"C:\Windows\Temp\v_knife_default_ct.vvd");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct_anim.ani", @"C:\Windows\Temp\v_knife_default_ct_anim.ani");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct_anim.mdl", @"C:\Windows\Temp\v_knife_default_ct_anim.mdl");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct_inspect.dx90.vtx", @"C:\Windows\Temp\v_knife_default_ct_inspect.dx90.vtx");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct_inspect.mdl", @"C:\Windows\Temp\v_knife_default_ct_inspect.mdl");
                        client.DownloadFile("https://github.com/zSniiKeR/RzxHp3X39231/raw/main/Bowie/Lado%20CT/v_knife_default_ct_inspect.vvd", @"C:\Windows\Temp\v_knife_default_ct_inspect.vvd");
                    }
                    break;
case "Butterfly":
txtDisplay.Text = "Butterfly";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_butterfly.794147e84a4e9426202d45145910cbb007797ce5.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Classic Knife":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*txtDisplay.Text = "Classic Knife";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_css.0b33071c28c02e6f19e363dc9a838566c6557389.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Falchion":
txtDisplay.Text = "Falchion";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_falchion.adcc43a018fd4fe315dbdbc7960cfc52c5d63e3e.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Flip Knife":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    //txtDisplay.Text = "Flip Knife";
                    //pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_flip.ebfc00735792b1e2947b30a321a07215dae8ceed.png");
                    //pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
case "Gut Knife":
txtDisplay.Text = "Gut Knife";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_gut.1d53007384970e8eaf28448312777683fd633a79.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Huntsman":
txtDisplay.Text = "Huntsman";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_tactical.7621bbad70410deb629d60ed98ef248dac525356.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Karambit":
txtDisplay.Text = "Karambit";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_karambit.8b491b581a4b9c7b5298071425f2b29a39a2a12f.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "M9 Bayonet":
txtDisplay.Text = "M9 Bayonet";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_m9_bayonet.1a55109e0c88792e5d56ea04dc1f676e44f9dec2.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Navaja":
txtDisplay.Text = "Navaja";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_gypsy_jackknife.1a7e57791fa9383cce67d5915ffc442c7de2694a.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Nomad":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*txtDisplay.Text = "Nomad";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_outdoor.fdb3ce5ceef1584781759ef5a7bd6f819bf12e9b.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Paracord":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*txtDisplay.Text = "Paracord";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_cord.073b5fa991a256ec2264b1c1c581401631eb51cb.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;*/
break;
case "Shaddow Daggers":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    //txtDisplay.Text = "Shaddow Daggers";
                    //pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_push.13f409f23e653107c90711e5ab258b52b187ff6a.png");
                    //pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
case "Skeleton":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*txtDisplay.Text = "Skeleton";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_skeleton.1fc401a844008bcaa89f8381cbe7b550a051609d.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Stiletto":
                    
                    txtDisplay.Text = "Stiletto";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_stiletto.1aefe4ca0e433fc8c3f924ba362283e0666b5f8d.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
case "Survival":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*txtDisplay.Text = "Survival";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_canis.ae03aed81864dc2ee1e1118bb973418f910098ac.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Talon":
txtDisplay.Text = "Talon";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_widowmaker.a0842ad04cda9292483b8896d1dcdaffac9c2e5e.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Ursus":
txtDisplay.Text = "Ursus";
pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_ursus.34ecda985c12503df5b88e9bda1826f61cc9e80a.png");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
default:
txtDisplay.Text = "Faca Indisponível, tente outra.";
pictureBox1.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
break;
}

}

private void btnClear_Click(object sender, EventArgs e)
{
txtDisplay.Text = "";
txtDisplay.BackColor = Color.White;

}

private void lblCountries_Click(object sender, EventArgs e)
{

}

private void txtDisplay_TextChanged(object sender, EventArgs e)
{

}

private void button2_Click(object sender, EventArgs e)
{

}

private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
{

}

private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string knifeskintr = comboBox2.Text;
            switch (knifeskintr)
            {
                case "BUTTERFLYKNIFE | Crimson Web - 12":
                    txtDisplay.Text = "Butterfly - Marble Fade";
                    pictureBox1.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_butterfly.794147e84a4e9426202d45145910cbb007797ce5.png");
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                break;
            }
        }

//Select Knife Model TR
private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
{
string knifemodeltr = comboBox1.Text;
switch (knifemodeltr)
{
case "Bayonet":
textDisplay2.Text = "Bayonet";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_bayonet.515de291204d6d896724d9fbb6856fcc6054a787.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Bowie Knife":
textDisplay2.Text = "Bowie Knife";
pictureBox2.LoadAsync("https://steamuserimages-a.akamaihd.net/ugc/934939061706979025/D50F081FA7517CDD7EE8FBAE2C1A9EC372722D05/");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Butterfly":
textDisplay2.Text = "Butterfly";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_butterfly.794147e84a4e9426202d45145910cbb007797ce5.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Classic Knife":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox2.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*textDisplay2.Text = "Classic Knife";
                    pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_css.0b33071c28c02e6f19e363dc9a838566c6557389.png");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Falchion":
textDisplay2.Text = "Falchion";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_falchion.adcc43a018fd4fe315dbdbc7960cfc52c5d63e3e.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Flip Knife":
textDisplay2.Text = "Flip Knife";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_flip.ebfc00735792b1e2947b30a321a07215dae8ceed.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Gut Knife":
textDisplay2.Text = "Gut Knife";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_gut.1d53007384970e8eaf28448312777683fd633a79.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Huntsman":
textDisplay2.Text = "Huntsman";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_tactical.7621bbad70410deb629d60ed98ef248dac525356.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Karambit":
textDisplay2.Text = "Karambit";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_karambit.8b491b581a4b9c7b5298071425f2b29a39a2a12f.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "M9 Bayonet":
textDisplay2.Text = "M9 Bayonet";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_m9_bayonet.1a55109e0c88792e5d56ea04dc1f676e44f9dec2.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Navaja":
textDisplay2.Text = "Navaja";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_gypsy_jackknife.1a7e57791fa9383cce67d5915ffc442c7de2694a.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Nomad":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox2.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*textDisplay2.Text = "Nomad";
                    pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_outdoor.fdb3ce5ceef1584781759ef5a7bd6f819bf12e9b.png");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Paracord":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox2.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*textDisplay2.Text = "Paracord";
                    pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_cord.073b5fa991a256ec2264b1c1c581401631eb51cb.png");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Shaddow Daggers":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox2.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;

                    /*textDisplay2.Text = "Shaddow Daggers";
                    pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_push.13f409f23e653107c90711e5ab258b52b187ff6a.png");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Skeleton":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox2.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*textDisplay2.Text = "Skeleton";
                    pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_skeleton.1fc401a844008bcaa89f8381cbe7b550a051609d.png");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Stiletto":
textDisplay2.Text = "Stiletto";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_stiletto.1aefe4ca0e433fc8c3f924ba362283e0666b5f8d.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Survival":
                    txtDisplay.Text = "Faca Indisponível, tente outra.";
                    pictureBox2.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    /*textDisplay2.Text = "Survival";
                    pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_canis.ae03aed81864dc2ee1e1118bb973418f910098ac.png");
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;*/
                    break;
case "Talon":
textDisplay2.Text = "Talon";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_widowmaker.a0842ad04cda9292483b8896d1dcdaffac9c2e5e.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
case "Ursus":
textDisplay2.Text = "Ursus";
pictureBox2.LoadAsync("https://steamcdn-a.akamaihd.net/apps/730/icons/econ/weapons/base_weapons/weapon_knife_ursus.34ecda985c12503df5b88e9bda1826f61cc9e80a.png");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
default:
textDisplay2.Text = "Faca Indisponível, tente outra.";
pictureBox2.LoadAsync("https://usernamehw.gallerycdn.vsassets.io/extensions/usernamehw/errorlens/3.6.0/1658612570729/Microsoft.VisualStudio.Services.Icons.Default");
pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
break;
}
}

}
}
