﻿namespace ComboBox
{
    partial class SelectionSwitchStatement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboCountries = new System.Windows.Forms.ComboBox();
            this.lblCountries = new System.Windows.Forms.Label();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textDisplay2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cboCountries
            // 
            this.cboCountries.FormattingEnabled = true;
            this.cboCountries.Items.AddRange(new object[] {
            "Bayonet",
            "Bowie Knife",
            "Butterfly",
            "Classic Knife",
            "Falchion",
            "Flip Knife",
            "Gut Knife",
            "Huntsman",
            "Karambit",
            "M9 Bayonet",
            "Navaja",
            "Nomad",
            "Paracord",
            "Shaddow Daggers",
            "Skeleton",
            "Stiletto",
            "Survival",
            "Talon",
            "Ursus"});
            this.cboCountries.Location = new System.Drawing.Point(27, 28);
            this.cboCountries.Name = "cboCountries";
            this.cboCountries.Size = new System.Drawing.Size(227, 21);
            this.cboCountries.TabIndex = 0;
            this.cboCountries.SelectedIndexChanged += new System.EventHandler(this.cboCountries_SelectedIndexChanged);
            // 
            // lblCountries
            // 
            this.lblCountries.AutoSize = true;
            this.lblCountries.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountries.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCountries.Location = new System.Drawing.Point(24, 12);
            this.lblCountries.Name = "lblCountries";
            this.lblCountries.Size = new System.Drawing.Size(110, 13);
            this.lblCountries.TabIndex = 1;
            this.lblCountries.Text = "MODEL KNIFE CT";
            this.lblCountries.Click += new System.EventHandler(this.lblCountries_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.ForeColor = System.Drawing.SystemColors.Menu;
            this.txtDisplay.Location = new System.Drawing.Point(549, 28);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.ReadOnly = true;
            this.txtDisplay.Size = new System.Drawing.Size(125, 33);
            this.txtDisplay.TabIndex = 8;
            this.txtDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDisplay.TextChanged += new System.EventHandler(this.txtDisplay_TextChanged);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(539, 337);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(178, 23);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "PACKDIR UPDATE";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(279, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "MODEL KNIFE TR";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Bayonet",
            "Bowie Knife",
            "Butterfly",
            "Classic Knife",
            "Falchion",
            "Flip Knife",
            "Gut Knife",
            "Huntsman",
            "Karambit",
            "M9 Bayonet",
            "Navaja",
            "Nomad",
            "Paracord",
            "Shaddow Daggers",
            "Skeleton",
            "Stiletto",
            "Survival",
            "Talon",
            "Ursus"});
            this.comboBox1.Location = new System.Drawing.Point(282, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(227, 21);
            this.comboBox1.TabIndex = 11;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(24, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "KNIFE SKIN CT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(279, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "KNIFE SKIN TR";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "//Navaja Knife Skins",
            "",
            "NAVAJAKNIFE | Doppler Phase 1 - 418",
            "NAVAJAKNIFE | Doppler Phase 2 - 419",
            "NAVAJAKNIFE | Doppler Phase 3 - 420",
            "NAVAJAKNIFE | Doppler Phase 4 - 421",
            "NAVAJAKNIFE | Doppler Ruby - 415",
            "NAVAJAKNIFE | Doppler Sapphire - 416",
            "NAVAJAKNIFE | Doppler Black Pearl - 417",
            "NAVAJAKNIFE | Marble Fade - 413",
            "NAVAJAKNIFE | Tiger Tooth - 409",
            "NAVAJAKNIFE | Ultraviolet - 98",
            "NAVAJAKNIFE | Damascus Steel - 857",
            "NAVAJAKNIFE | Rust Coat - 414",
            "NAVAJAKNIFE | Fade - 38",
            "NAVAJAKNIFE | Slaughter - 59",
            "NAVAJAKNIFE | Crimson Web - 12",
            "NAVAJAKNIFE | Case Hardened - 44",
            "NAVAJAKNIFE | Blue Steel - 42",
            "NAVAJAKNIFE | Scorched - 175",
            "NAVAJAKNIFE | Urban Masked - 143",
            "NAVAJAKNIFE | Night Stripe - 735",
            "NAVAJAKNIFE | Stained - 43",
            "NAVAJAKNIFE | Forest DDPAT - 5",
            "NAVAJAKNIFE | Boreal Forest - 77",
            "NAVAJAKNIFE | Safari Mesh - 72",
            "",
            "",
            "//Stiletto Knife Skins",
            "",
            "STILETTOKNIFE | Doppler Phase 1 - 418",
            "STILETTOKNIFE | Doppler Phase 2 - 419",
            "STILETTOKNIFE | Doppler Phase 3 - 420",
            "STILETTOKNIFE | Doppler Phase 4 - 421",
            "STILETTOKNIFE | Doppler Ruby - 415",
            "STILETTOKNIFE | Doppler Sapphire - 416",
            "STILETTOKNIFE | Doppler Black Pearl - 417",
            "STILETTOKNIFE | Marble Fade - 413",
            "STILETTOKNIFE | Tiger Tooth - 409",
            "STILETTOKNIFE | Damascus Steel - 857",
            "STILETTOKNIFE | Ultraviolet - 98",
            "STILETTOKNIFE | Rust Coat - 414",
            "STILETTOKNIFE | Fade - 38",
            "STILETTOKNIFE | Slaughter - 59",
            "STILETTOKNIFE | Case Hardened - 44",
            "STILETTOKNIFE | Crimson Web - 12",
            "STILETTOKNIFE | Night Stripe - 735",
            "STILETTOKNIFE | Boreal Forest - 77",
            "STILETTOKNIFE | Blue Steel - 42",
            "STILETTOKNIFE | Stained - 43",
            "STILETTOKNIFE | Safari Mesh - 72",
            "STILETTOKNIFE | Urban Masked - 143",
            "STILETTOKNIFE | Scorched - 175",
            "STILETTOKNIFE | Forest DDPAT - 5",
            "",
            "",
            "//Talon Knife Skins",
            "",
            "TALONKNIFE | Marble Fade - 856",
            "TALONKNIFE | Doppler Phase 1 - 852",
            "TALONKNIFE | Doppler Phase 2 - 853",
            "TALONKNIFE | Doppler Phase 3 - 854",
            "TALONKNIFE | Doppler Phase 4 - 855",
            "TALONKNIFE | Doppler Ruby - 415",
            "TALONKNIFE | Doppler Sapphire - 416",
            "TALONKNIFE | Doppler Black Pearl - 417",
            "TALONKNIFE | Tiger Tooth - 409",
            "TALONKNIFE | Damascus Steel - 858",
            "TALONKNIFE | Ultraviolet - 98",
            "TALONKNIFE | Rust Coat - 414",
            "TALONKNIFE | Fade - 38",
            "TALONKNIFE | Slaughter - 59",
            "TALONKNIFE | Crimson Web - 12",
            "TALONKNIFE | Blue Steel - 42",
            "TALONKNIFE | Case Hardened - 44",
            "TALONKNIFE | Stained - 43",
            "TALONKNIFE | Night Stripe - 735",
            "TALONKNIFE | Safari Mesh - 72",
            "TALONKNIFE | Scorched - 175",
            "TALONKNIFE | Forest DDPAT - 5",
            "TALONKNIFE | Boreal Forest - 77",
            "TALONKNIFE | Urban Masked - 143",
            "",
            "",
            "//Ursus Knife Skins",
            "",
            "URSUSKNIFE | Marble Fade - 413",
            "URSUSKNIFE | Ultraviolet - 98",
            "URSUSKNIFE | Doppler Phase 1 - 418",
            "URSUSKNIFE | Doppler Phase 2 - 419",
            "URSUSKNIFE | Doppler Phase 3 - 420",
            "URSUSKNIFE | Doppler Phase 4 - 421",
            "URSUSKNIFE | Doppler Ruby - 415",
            "URSUSKNIFE | Doppler Sapphire - 416",
            "URSUSKNIFE | Doppler Black Pearl - 417",
            "URSUSKNIFE | Damascus Steel - 857",
            "URSUSKNIFE | Tiger Tooth - 409",
            "URSUSKNIFE | Rust Coat - 414",
            "URSUSKNIFE | Fade - 38",
            "URSUSKNIFE | Slaughter - 59",
            "URSUSKNIFE | Crimson Web - 12",
            "URSUSKNIFE | Case Hardened - 44",
            "URSUSKNIFE | Blue Steel - 42",
            "URSUSKNIFE | Night Stripe - 735",
            "URSUSKNIFE | Urban Masked - 143",
            "URSUSKNIFE | Stained - 43",
            "URSUSKNIFE | Scorched - 175",
            "URSUSKNIFE | Forest DDPAT - 5",
            "URSUSKNIFE | Boreal Forest - 77",
            "URSUSKNIFE | Safari Mesh - 72",
            "",
            "",
            "//Bayonet Skins",
            "",
            "BAYONET | Gamma Doppler Phase 1 - 569",
            "BAYONET | Gamma Doppler Phase 2 - 570",
            "BAYONET | Gamma Doppler Phase 3 - 571",
            "BAYONET | Gamma Doppler Phase 4 - 572",
            "BAYONET | Gamma Doppler Emerald - 568",
            "BAYONET | Lore - 558",
            "BAYONET | Autotronic - 573",
            "BAYONET | Black Laminate - 563",
            "BAYONET | Freehand - 580",
            "BAYONET | Bright Water - 578",
            "BAYONET | Marble Fade - 413",
            "BAYONET | Tiger Tooth - 409",
            "BAYONET | Doppler Phase 1 - 418",
            "BAYONET | Doppler Phase 2 - 419",
            "BAYONET | Doppler Phase 3 - 420",
            "BAYONET | Doppler Phase 4 - 421",
            "BAYONET | Doppler Ruby - 415",
            "BAYONET | Doppler Sapphire - 416",
            "BAYONET | Doppler Black Pearl - 417",
            "BAYONET | Rust Coat - 414",
            "BAYONET | Damascus Steel - 410",
            "BAYONET | Ultraviolet - 98",
            "BAYONET | Fade - 38",
            "BAYONET | Slaughter - 59",
            "BAYONET | Case Hardened - 44",
            "BAYONET | Blue Steel - 42",
            "BAYONET | Crimson Web - 12",
            "BAYONET | Night - 40",
            "BAYONET | Boreal Forest - 77",
            "BAYONET | Stained - 43",
            "BAYONET | Safari Mesh - 72",
            "BAYONET | Scorched - 175",
            "BAYONET | Forest DDPAT - 5",
            "BAYONET | Urban Masked - 143",
            "",
            "",
            "//Bowie Knife Skins",
            "",
            "BOWIEKNIFE | Doppler Phase 1 - 418",
            "BOWIEKNIFE | Doppler Phase 2 - 419",
            "BOWIEKNIFE | Doppler Phase 3 - 420",
            "BOWIEKNIFE | Doppler Phase 4 - 421",
            "BOWIEKNIFE | Doppler Ruby - 415",
            "BOWIEKNIFE | Doppler Sapphire - 416",
            "BOWIEKNIFE | Doppler Black Pearl - 417",
            "BOWIEKNIFE | Marble Fade - 413",
            "BOWIEKNIFE | Ultraviolet - 98",
            "BOWIEKNIFE | Tiger Tooth - 409",
            "BOWIEKNIFE | Rust Coat - 414",
            "BOWIEKNIFE | Damascus Steel - 411",
            "BOWIEKNIFE | Fade - 38",
            "BOWIEKNIFE | Slaughter - 59",
            "BOWIEKNIFE | Crimson Web - 12",
            "BOWIEKNIFE | Case Hardened - 44",
            "BOWIEKNIFE | Night - 40",
            "BOWIEKNIFE | Blue Steel - 42",
            "BOWIEKNIFE | Stained - 43",
            "BOWIEKNIFE | Boreal Forest - 77",
            "BOWIEKNIFE | Urban Masked - 143",
            "BOWIEKNIFE | Forest DDPAT - 5",
            "BOWIEKNIFE | Scorched - 175",
            "BOWIEKNIFE | Safari Mesh - 72",
            "",
            "",
            "//Butterfly Knife Skins",
            "",
            "BUTTERFLYKNIFE | Marble Fade - 413",
            "BUTTERFLYKNIFE | Doppler Phase 1 - 418",
            "BUTTERFLYKNIFE | Doppler Phase 2 - 618",
            "BUTTERFLYKNIFE | Doppler Phase 3 - 420",
            "BUTTERFLYKNIFE | Doppler Phase 4 - 421",
            "BUTTERFLYKNIFE | Doppler Ruby - 415",
            "BUTTERFLYKNIFE | Doppler Sapphire - 619",
            "BUTTERFLYKNIFE | Doppler Black Pearl - 617",
            "BUTTERFLYKNIFE | Tiger Tooth - 409",
            "BUTTERFLYKNIFE | Damascus Steel - 411",
            "BUTTERFLYKNIFE | Rust Coat - 414",
            "BUTTERFLYKNIFE | Ultraviolet - 98",
            "BUTTERFLYKNIFE | Fade - 38",
            "BUTTERFLYKNIFE | Slaughter - 59",
            "BUTTERFLYKNIFE | Case Hardened - 44",
            "BUTTERFLYKNIFE | Crimson Web - 12",
            "BUTTERFLYKNIFE | Blue Steel - 42",
            "BUTTERFLYKNIFE | Boreal Forest - 77",
            "BUTTERFLYKNIFE | Night - 40",
            "BUTTERFLYKNIFE | Forest DDPAT - 5",
            "BUTTERFLYKNIFE | Stained - 43",
            "BUTTERFLYKNIFE | Urban Masked - 143",
            "BUTTERFLYKNIFE | Safari Mesh - 72",
            "BUTTERFLYKNIFE | Scorched - 175",
            "",
            "",
            "//Falchion Knife Skins",
            "",
            "FALCHIONKNIFE | Doppler Phase 1 - 418",
            "FALCHIONKNIFE | Doppler Phase 2 - 419",
            "FALCHIONKNIFE | Doppler Phase 3 - 420",
            "FALCHIONKNIFE | Doppler Phase 4 - 421",
            "FALCHIONKNIFE | Doppler Ruby - 415",
            "FALCHIONKNIFE | Doppler Sapphire - 416",
            "FALCHIONKNIFE | Doppler Black Pearl - 417",
            "FALCHIONKNIFE | Marble Fade - 413",
            "FALCHIONKNIFE | Ultraviolet - 621",
            "FALCHIONKNIFE | Tiger Tooth - 409",
            "FALCHIONKNIFE | Damascus Steel - 411",
            "FALCHIONKNIFE | Rust Coat - 414",
            "FALCHIONKNIFE | Fade - 38",
            "FALCHIONKNIFE | Slaughter - 59",
            "FALCHIONKNIFE | Crimson Web - 12",
            "FALCHIONKNIFE | Night - 40",
            "FALCHIONKNIFE | Case Hardened - 44",
            "FALCHIONKNIFE | Blue Steel - 42",
            "FALCHIONKNIFE | Scorched - 175",
            "FALCHIONKNIFE | Forest DDPAT - 5",
            "FALCHIONKNIFE | Stained - 43",
            "FALCHIONKNIFE | Boreal Forest - 77",
            "FALCHIONKNIFE | Safari Mesh - 72",
            "FALCHIONKNIFE | Urban Masked - 143",
            "",
            "",
            "//Flip Knife Skins",
            "",
            "FLIPKNIFE | Autotronic - 574",
            "FLIPKNIFE | Gamma Doppler Phase 1 - 569",
            "FLIPKNIFE | Gamma Doppler Phase 2 - 570",
            "FLIPKNIFE | Gamma Doppler Phase 3 - 571",
            "FLIPKNIFE | Gamma Doppler Phase 4 - 572",
            "FLIPKNIFE | Gamma Doppler Emerald - 568",
            "FLIPKNIFE | Lore - 559",
            "FLIPKNIFE | Freehand - 580",
            "FLIPKNIFE | Bright Water - 578",
            "FLIPKNIFE | Black Laminate - 564",
            "FLIPKNIFE | Tiger Tooth - 409",
            "FLIPKNIFE | Marble Fade - 413",
            "FLIPKNIFE | Doppler Phase 1 - 418",
            "FLIPKNIFE | Doppler Phase 2 - 419",
            "FLIPKNIFE | Doppler Phase 3 - 420",
            "FLIPKNIFE | Doppler Phase 4 - 421",
            "FLIPKNIFE | Doppler Ruby - 415",
            "FLIPKNIFE | Doppler Sapphire - 416",
            "FLIPKNIFE | Doppler Black Pearl - 417",
            "FLIPKNIFE | Ultraviolet - 98",
            "FLIPKNIFE | Damascus Steel - 410",
            "FLIPKNIFE | Rust Coat - 414",
            "FLIPKNIFE | Crimson Web - 12",
            "FLIPKNIFE | Fade - 38",
            "FLIPKNIFE | Slaughter - 59",
            "FLIPKNIFE | Case Hardened - 44",
            "FLIPKNIFE | Blue Steel - 42",
            "FLIPKNIFE | Urban Masked - 143",
            "FLIPKNIFE | Night - 40",
            "FLIPKNIFE | Stained - 43",
            "FLIPKNIFE | Forest DDPAT - 5",
            "FLIPKNIFE | Safari Mesh - 72",
            "FLIPKNIFE | Boreal Forest - 77",
            "FLIPKNIFE | Scorched - 175",
            "",
            "",
            "//Gut Knife Skins",
            "",
            "GUTKNIFE | Lore - 560",
            "GUTKNIFE | Autotronic - 575",
            "GUTKNIFE | Gamma Doppler Phase 1 - 569",
            "GUTKNIFE | Gamma Doppler Phase 2 - 570",
            "GUTKNIFE | Gamma Doppler Phase 3 - 571",
            "GUTKNIFE | Gamma Doppler Phase 4 - 572",
            "GUTKNIFE | Gamma Doppler Emerald - 568",
            "GUTKNIFE | Black Laminate - 565",
            "GUTKNIFE | Freehand - 580",
            "GUTKNIFE | Bright Water - 578",
            "GUTKNIFE | Marble Fade - 413",
            "GUTKNIFE | Doppler Phase 1 - 418",
            "GUTKNIFE | Doppler Phase 2 - 419",
            "GUTKNIFE | Doppler Phase 3 - 420",
            "GUTKNIFE | Doppler Phase 4 - 421",
            "GUTKNIFE | Doppler Ruby - 415",
            "GUTKNIFE | Doppler Sapphire - 416",
            "GUTKNIFE | Doppler Black Pearl - 417",
            "GUTKNIFE | Tiger Tooth - 409",
            "GUTKNIFE | Damascus Steel - 410",
            "GUTKNIFE | Ultraviolet - 98",
            "GUTKNIFE | Rust Coat - 414",
            "GUTKNIFE | Stained - 43",
            "GUTKNIFE | Crimson Web - 12",
            "GUTKNIFE | Blue Steel - 42",
            "GUTKNIFE | Case Hardened - 44",
            "GUTKNIFE | Fade - 38",
            "GUTKNIFE | Slaughter - 59",
            "GUTKNIFE | Urban Masked - 143",
            "GUTKNIFE | Night - 40",
            "GUTKNIFE | Boreal Forest - 77",
            "GUTKNIFE | Forest DDPAT - 5",
            "GUTKNIFE | Safari Mesh - 72",
            "GUTKNIFE | Scorched - 175",
            "",
            "",
            "//Huntsman Knife Skins",
            "",
            "HUNTSMANKNIFE | Marble Fade - 413",
            "HUNTSMANKNIFE | Doppler Phase 1 - 418",
            "HUNTSMANKNIFE | Doppler Phase 2 - 419",
            "HUNTSMANKNIFE | Doppler Phase 3 - 420",
            "HUNTSMANKNIFE | Doppler Phase 4 - 421",
            "HUNTSMANKNIFE | Doppler Ruby - 415",
            "HUNTSMANKNIFE | Doppler Sapphire - 416",
            "HUNTSMANKNIFE | Doppler Black Pearl - 417",
            "HUNTSMANKNIFE | Tiger Tooth - 409",
            "HUNTSMANKNIFE | Damascus Steel - 411",
            "HUNTSMANKNIFE | Ultraviolet - 620",
            "HUNTSMANKNIFE | Rust Coat - 414",
            "HUNTSMANKNIFE | Fade - 38",
            "HUNTSMANKNIFE | Case Hardened - 44",
            "HUNTSMANKNIFE | Slaughter - 59",
            "HUNTSMANKNIFE | Crimson Web - 12",
            "HUNTSMANKNIFE | Blue Steel - 42",
            "HUNTSMANKNIFE | Night - 40",
            "HUNTSMANKNIFE | Scorched - 175",
            "HUNTSMANKNIFE | Boreal Forest - 77",
            "HUNTSMANKNIFE | Stained - 43",
            "HUNTSMANKNIFE | Safari Mesh - 72",
            "HUNTSMANKNIFE | Forest DDPAT - 5",
            "HUNTSMANKNIFE | Urban Masked - 143",
            "",
            "",
            "//Karambit Skins",
            "",
            "KARAMBIT | Lore - 561",
            "KARAMBIT | Autotronic - 576",
            "KARAMBIT | Gamma Doppler Phase 1 - 569",
            "KARAMBIT | Gamma Doppler Phase 2 - 570",
            "KARAMBIT | Gamma Doppler Phase 3 - 571",
            "KARAMBIT | Gamma Doppler Phase 4 - 572",
            "KARAMBIT | Gamma Doppler Emerald - 568",
            "KARAMBIT | Black Laminate - 566",
            "KARAMBIT | Freehand - 582",
            "KARAMBIT | Bright Water - 578",
            "KARAMBIT | Marble Fade - 413",
            "KARAMBIT | Tiger Tooth - 409",
            "KARAMBIT | Doppler Phase 1 - 418",
            "KARAMBIT | Doppler Phase 2 - 419",
            "KARAMBIT | Doppler Phase 3 - 420",
            "KARAMBIT | Doppler Phase 4 - 421",
            "KARAMBIT | Doppler Ruby - 415",
            "KARAMBIT | Doppler Sapphire - 416",
            "KARAMBIT | Doppler Black Pearl - 417",
            "KARAMBIT | Damascus Steel - 410",
            "KARAMBIT | Ultraviolet - 98",
            "KARAMBIT | Rust Coat - 414",
            "KARAMBIT | Fade - 38",
            "KARAMBIT | Slaughter - 59",
            "KARAMBIT | Case Hardened - 44",
            "KARAMBIT | Night - 40",
            "KARAMBIT | Crimson Web - 12",
            "KARAMBIT | Stained - 43",
            "KARAMBIT | Blue Steel - 42",
            "KARAMBIT | Boreal Forest - 77",
            "KARAMBIT | Safari Mesh - 72",
            "KARAMBIT | Scorched - 175",
            "KARAMBIT | Forest DDPAT - 5",
            "KARAMBIT | Urban Masked - 143",
            "",
            "",
            "//M9 Bayonet Skins",
            "",
            "M9BAYONET | Lore - 562",
            "M9BAYONET | Autotronic - 577",
            "M9BAYONET | Gamma Doppler Phase 1 - 569",
            "M9BAYONET | Gamma Doppler Phase 2 - 570",
            "M9BAYONET | Gamma Doppler Phase 3 - 571",
            "M9BAYONET | Gamma Doppler Phase 4 - 572",
            "M9BAYONET | Gamma Doppler Emerald - 568",
            "M9BAYONET | Black Laminate - 567",
            "M9BAYONET | Freehand - 581",
            "M9BAYONET | Bright Water - 579",
            "M9BAYONET | Marble Fade - 413",
            "M9BAYONET | Tiger Tooth - 409",
            "M9BAYONET | Doppler Phase 1 - 418",
            "M9BAYONET | Doppler Phase 2 - 419",
            "M9BAYONET | Doppler Phase 3 - 420",
            "M9BAYONET | Doppler Phase 4 - 421",
            "M9BAYONET | Doppler Ruby - 415",
            "M9BAYONET | Doppler Sapphire - 416",
            "M9BAYONET | Doppler Black Pearl - 417",
            "M9BAYONET | Damascus Steel - 411",
            "M9BAYONET | Rust Coat - 414",
            "M9BAYONET | Ultraviolet - 98",
            "M9BAYONET | Fade - 38",
            "M9BAYONET | Slaughter - 59",
            "M9BAYONET | Crimson Web - 12",
            "M9BAYONET | Case Hardened - 44",
            "M9BAYONET | Night - 40",
            "M9BAYONET | Blue Steel - 42",
            "M9BAYONET | Boreal Forest - 77",
            "M9BAYONET | Stained - 43",
            "M9BAYONET | Scorched - 175",
            "M9BAYONET | Urban Masked - 143",
            "M9BAYONET | Forest DDPAT - 5",
            "M9BAYONET | Safari Mesh - 72",
            "",
            "",
            "//Shadow Daggers Skins",
            "",
            "SHADOWDAGGERS | Marble Fade - 413",
            "SHADOWDAGGERS | Doppler Phase 1 - 418",
            "SHADOWDAGGERS | Doppler Phase 2 - 618",
            "SHADOWDAGGERS | Doppler Phase 3 - 420",
            "SHADOWDAGGERS | Doppler Phase 4 - 421",
            "SHADOWDAGGERS | Doppler Ruby - 415",
            "SHADOWDAGGERS | Doppler Sapphire - 619",
            "SHADOWDAGGERS | Doppler Black Pearl - 617",
            "SHADOWDAGGERS | Tiger Tooth - 409",
            "SHADOWDAGGERS | Ultraviolet - 98",
            "SHADOWDAGGERS | Damascus Steel - 411",
            "SHADOWDAGGERS | Rust Coat - 414",
            "SHADOWDAGGERS | Night - 40",
            "SHADOWDAGGERS | Fade - 38",
            "SHADOWDAGGERS | Slaughter - 59",
            "SHADOWDAGGERS | Crimson Web - 12",
            "SHADOWDAGGERS | Case Hardened - 44",
            "SHADOWDAGGERS | Blue Steel - 42",
            "SHADOWDAGGERS | Urban Masked - 143",
            "SHADOWDAGGERS | Boreal Forest - 77",
            "SHADOWDAGGERS | Scorched - 175",
            "SHADOWDAGGERS | Forest DDPAT - 5",
            "SHADOWDAGGERS | Stained - 43",
            "SHADOWDAGGERS | Safari Mesh - 72"});
            this.comboBox2.Location = new System.Drawing.Point(27, 98);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(227, 21);
            this.comboBox2.TabIndex = 14;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "//Navaja Knife Skins",
            "",
            "NAVAJAKNIFE | Doppler Phase 1 - 418",
            "NAVAJAKNIFE | Doppler Phase 2 - 419",
            "NAVAJAKNIFE | Doppler Phase 3 - 420",
            "NAVAJAKNIFE | Doppler Phase 4 - 421",
            "NAVAJAKNIFE | Doppler Ruby - 415",
            "NAVAJAKNIFE | Doppler Sapphire - 416",
            "NAVAJAKNIFE | Doppler Black Pearl - 417",
            "NAVAJAKNIFE | Marble Fade - 413",
            "NAVAJAKNIFE | Tiger Tooth - 409",
            "NAVAJAKNIFE | Ultraviolet - 98",
            "NAVAJAKNIFE | Damascus Steel - 857",
            "NAVAJAKNIFE | Rust Coat - 414",
            "NAVAJAKNIFE | Fade - 38",
            "NAVAJAKNIFE | Slaughter - 59",
            "NAVAJAKNIFE | Crimson Web - 12",
            "NAVAJAKNIFE | Case Hardened - 44",
            "NAVAJAKNIFE | Blue Steel - 42",
            "NAVAJAKNIFE | Scorched - 175",
            "NAVAJAKNIFE | Urban Masked - 143",
            "NAVAJAKNIFE | Night Stripe - 735",
            "NAVAJAKNIFE | Stained - 43",
            "NAVAJAKNIFE | Forest DDPAT - 5",
            "NAVAJAKNIFE | Boreal Forest - 77",
            "NAVAJAKNIFE | Safari Mesh - 72",
            "",
            "",
            "//Stiletto Knife Skins",
            "",
            "STILETTOKNIFE | Doppler Phase 1 - 418",
            "STILETTOKNIFE | Doppler Phase 2 - 419",
            "STILETTOKNIFE | Doppler Phase 3 - 420",
            "STILETTOKNIFE | Doppler Phase 4 - 421",
            "STILETTOKNIFE | Doppler Ruby - 415",
            "STILETTOKNIFE | Doppler Sapphire - 416",
            "STILETTOKNIFE | Doppler Black Pearl - 417",
            "STILETTOKNIFE | Marble Fade - 413",
            "STILETTOKNIFE | Tiger Tooth - 409",
            "STILETTOKNIFE | Damascus Steel - 857",
            "STILETTOKNIFE | Ultraviolet - 98",
            "STILETTOKNIFE | Rust Coat - 414",
            "STILETTOKNIFE | Fade - 38",
            "STILETTOKNIFE | Slaughter - 59",
            "STILETTOKNIFE | Case Hardened - 44",
            "STILETTOKNIFE | Crimson Web - 12",
            "STILETTOKNIFE | Night Stripe - 735",
            "STILETTOKNIFE | Boreal Forest - 77",
            "STILETTOKNIFE | Blue Steel - 42",
            "STILETTOKNIFE | Stained - 43",
            "STILETTOKNIFE | Safari Mesh - 72",
            "STILETTOKNIFE | Urban Masked - 143",
            "STILETTOKNIFE | Scorched - 175",
            "STILETTOKNIFE | Forest DDPAT - 5",
            "",
            "",
            "//Talon Knife Skins",
            "",
            "TALONKNIFE | Marble Fade - 856",
            "TALONKNIFE | Doppler Phase 1 - 852",
            "TALONKNIFE | Doppler Phase 2 - 853",
            "TALONKNIFE | Doppler Phase 3 - 854",
            "TALONKNIFE | Doppler Phase 4 - 855",
            "TALONKNIFE | Doppler Ruby - 415",
            "TALONKNIFE | Doppler Sapphire - 416",
            "TALONKNIFE | Doppler Black Pearl - 417",
            "TALONKNIFE | Tiger Tooth - 409",
            "TALONKNIFE | Damascus Steel - 858",
            "TALONKNIFE | Ultraviolet - 98",
            "TALONKNIFE | Rust Coat - 414",
            "TALONKNIFE | Fade - 38",
            "TALONKNIFE | Slaughter - 59",
            "TALONKNIFE | Crimson Web - 12",
            "TALONKNIFE | Blue Steel - 42",
            "TALONKNIFE | Case Hardened - 44",
            "TALONKNIFE | Stained - 43",
            "TALONKNIFE | Night Stripe - 735",
            "TALONKNIFE | Safari Mesh - 72",
            "TALONKNIFE | Scorched - 175",
            "TALONKNIFE | Forest DDPAT - 5",
            "TALONKNIFE | Boreal Forest - 77",
            "TALONKNIFE | Urban Masked - 143",
            "",
            "",
            "//Ursus Knife Skins",
            "",
            "URSUSKNIFE | Marble Fade - 413",
            "URSUSKNIFE | Ultraviolet - 98",
            "URSUSKNIFE | Doppler Phase 1 - 418",
            "URSUSKNIFE | Doppler Phase 2 - 419",
            "URSUSKNIFE | Doppler Phase 3 - 420",
            "URSUSKNIFE | Doppler Phase 4 - 421",
            "URSUSKNIFE | Doppler Ruby - 415",
            "URSUSKNIFE | Doppler Sapphire - 416",
            "URSUSKNIFE | Doppler Black Pearl - 417",
            "URSUSKNIFE | Damascus Steel - 857",
            "URSUSKNIFE | Tiger Tooth - 409",
            "URSUSKNIFE | Rust Coat - 414",
            "URSUSKNIFE | Fade - 38",
            "URSUSKNIFE | Slaughter - 59",
            "URSUSKNIFE | Crimson Web - 12",
            "URSUSKNIFE | Case Hardened - 44",
            "URSUSKNIFE | Blue Steel - 42",
            "URSUSKNIFE | Night Stripe - 735",
            "URSUSKNIFE | Urban Masked - 143",
            "URSUSKNIFE | Stained - 43",
            "URSUSKNIFE | Scorched - 175",
            "URSUSKNIFE | Forest DDPAT - 5",
            "URSUSKNIFE | Boreal Forest - 77",
            "URSUSKNIFE | Safari Mesh - 72",
            "",
            "",
            "//Bayonet Skins",
            "",
            "BAYONET | Gamma Doppler Phase 1 - 569",
            "BAYONET | Gamma Doppler Phase 2 - 570",
            "BAYONET | Gamma Doppler Phase 3 - 571",
            "BAYONET | Gamma Doppler Phase 4 - 572",
            "BAYONET | Gamma Doppler Emerald - 568",
            "BAYONET | Lore - 558",
            "BAYONET | Autotronic - 573",
            "BAYONET | Black Laminate - 563",
            "BAYONET | Freehand - 580",
            "BAYONET | Bright Water - 578",
            "BAYONET | Marble Fade - 413",
            "BAYONET | Tiger Tooth - 409",
            "BAYONET | Doppler Phase 1 - 418",
            "BAYONET | Doppler Phase 2 - 419",
            "BAYONET | Doppler Phase 3 - 420",
            "BAYONET | Doppler Phase 4 - 421",
            "BAYONET | Doppler Ruby - 415",
            "BAYONET | Doppler Sapphire - 416",
            "BAYONET | Doppler Black Pearl - 417",
            "BAYONET | Rust Coat - 414",
            "BAYONET | Damascus Steel - 410",
            "BAYONET | Ultraviolet - 98",
            "BAYONET | Fade - 38",
            "BAYONET | Slaughter - 59",
            "BAYONET | Case Hardened - 44",
            "BAYONET | Blue Steel - 42",
            "BAYONET | Crimson Web - 12",
            "BAYONET | Night - 40",
            "BAYONET | Boreal Forest - 77",
            "BAYONET | Stained - 43",
            "BAYONET | Safari Mesh - 72",
            "BAYONET | Scorched - 175",
            "BAYONET | Forest DDPAT - 5",
            "BAYONET | Urban Masked - 143",
            "",
            "",
            "//Bowie Knife Skins",
            "",
            "BOWIEKNIFE | Doppler Phase 1 - 418",
            "BOWIEKNIFE | Doppler Phase 2 - 419",
            "BOWIEKNIFE | Doppler Phase 3 - 420",
            "BOWIEKNIFE | Doppler Phase 4 - 421",
            "BOWIEKNIFE | Doppler Ruby - 415",
            "BOWIEKNIFE | Doppler Sapphire - 416",
            "BOWIEKNIFE | Doppler Black Pearl - 417",
            "BOWIEKNIFE | Marble Fade - 413",
            "BOWIEKNIFE | Ultraviolet - 98",
            "BOWIEKNIFE | Tiger Tooth - 409",
            "BOWIEKNIFE | Rust Coat - 414",
            "BOWIEKNIFE | Damascus Steel - 411",
            "BOWIEKNIFE | Fade - 38",
            "BOWIEKNIFE | Slaughter - 59",
            "BOWIEKNIFE | Crimson Web - 12",
            "BOWIEKNIFE | Case Hardened - 44",
            "BOWIEKNIFE | Night - 40",
            "BOWIEKNIFE | Blue Steel - 42",
            "BOWIEKNIFE | Stained - 43",
            "BOWIEKNIFE | Boreal Forest - 77",
            "BOWIEKNIFE | Urban Masked - 143",
            "BOWIEKNIFE | Forest DDPAT - 5",
            "BOWIEKNIFE | Scorched - 175",
            "BOWIEKNIFE | Safari Mesh - 72",
            "",
            "",
            "//Butterfly Knife Skins",
            "",
            "BUTTERFLYKNIFE | Marble Fade - 413",
            "BUTTERFLYKNIFE | Doppler Phase 1 - 418",
            "BUTTERFLYKNIFE | Doppler Phase 2 - 618",
            "BUTTERFLYKNIFE | Doppler Phase 3 - 420",
            "BUTTERFLYKNIFE | Doppler Phase 4 - 421",
            "BUTTERFLYKNIFE | Doppler Ruby - 415",
            "BUTTERFLYKNIFE | Doppler Sapphire - 619",
            "BUTTERFLYKNIFE | Doppler Black Pearl - 617",
            "BUTTERFLYKNIFE | Tiger Tooth - 409",
            "BUTTERFLYKNIFE | Damascus Steel - 411",
            "BUTTERFLYKNIFE | Rust Coat - 414",
            "BUTTERFLYKNIFE | Ultraviolet - 98",
            "BUTTERFLYKNIFE | Fade - 38",
            "BUTTERFLYKNIFE | Slaughter - 59",
            "BUTTERFLYKNIFE | Case Hardened - 44",
            "BUTTERFLYKNIFE | Crimson Web - 12",
            "BUTTERFLYKNIFE | Blue Steel - 42",
            "BUTTERFLYKNIFE | Boreal Forest - 77",
            "BUTTERFLYKNIFE | Night - 40",
            "BUTTERFLYKNIFE | Forest DDPAT - 5",
            "BUTTERFLYKNIFE | Stained - 43",
            "BUTTERFLYKNIFE | Urban Masked - 143",
            "BUTTERFLYKNIFE | Safari Mesh - 72",
            "BUTTERFLYKNIFE | Scorched - 175",
            "",
            "",
            "//Falchion Knife Skins",
            "",
            "FALCHIONKNIFE | Doppler Phase 1 - 418",
            "FALCHIONKNIFE | Doppler Phase 2 - 419",
            "FALCHIONKNIFE | Doppler Phase 3 - 420",
            "FALCHIONKNIFE | Doppler Phase 4 - 421",
            "FALCHIONKNIFE | Doppler Ruby - 415",
            "FALCHIONKNIFE | Doppler Sapphire - 416",
            "FALCHIONKNIFE | Doppler Black Pearl - 417",
            "FALCHIONKNIFE | Marble Fade - 413",
            "FALCHIONKNIFE | Ultraviolet - 621",
            "FALCHIONKNIFE | Tiger Tooth - 409",
            "FALCHIONKNIFE | Damascus Steel - 411",
            "FALCHIONKNIFE | Rust Coat - 414",
            "FALCHIONKNIFE | Fade - 38",
            "FALCHIONKNIFE | Slaughter - 59",
            "FALCHIONKNIFE | Crimson Web - 12",
            "FALCHIONKNIFE | Night - 40",
            "FALCHIONKNIFE | Case Hardened - 44",
            "FALCHIONKNIFE | Blue Steel - 42",
            "FALCHIONKNIFE | Scorched - 175",
            "FALCHIONKNIFE | Forest DDPAT - 5",
            "FALCHIONKNIFE | Stained - 43",
            "FALCHIONKNIFE | Boreal Forest - 77",
            "FALCHIONKNIFE | Safari Mesh - 72",
            "FALCHIONKNIFE | Urban Masked - 143",
            "",
            "",
            "//Flip Knife Skins",
            "",
            "FLIPKNIFE | Autotronic - 574",
            "FLIPKNIFE | Gamma Doppler Phase 1 - 569",
            "FLIPKNIFE | Gamma Doppler Phase 2 - 570",
            "FLIPKNIFE | Gamma Doppler Phase 3 - 571",
            "FLIPKNIFE | Gamma Doppler Phase 4 - 572",
            "FLIPKNIFE | Gamma Doppler Emerald - 568",
            "FLIPKNIFE | Lore - 559",
            "FLIPKNIFE | Freehand - 580",
            "FLIPKNIFE | Bright Water - 578",
            "FLIPKNIFE | Black Laminate - 564",
            "FLIPKNIFE | Tiger Tooth - 409",
            "FLIPKNIFE | Marble Fade - 413",
            "FLIPKNIFE | Doppler Phase 1 - 418",
            "FLIPKNIFE | Doppler Phase 2 - 419",
            "FLIPKNIFE | Doppler Phase 3 - 420",
            "FLIPKNIFE | Doppler Phase 4 - 421",
            "FLIPKNIFE | Doppler Ruby - 415",
            "FLIPKNIFE | Doppler Sapphire - 416",
            "FLIPKNIFE | Doppler Black Pearl - 417",
            "FLIPKNIFE | Ultraviolet - 98",
            "FLIPKNIFE | Damascus Steel - 410",
            "FLIPKNIFE | Rust Coat - 414",
            "FLIPKNIFE | Crimson Web - 12",
            "FLIPKNIFE | Fade - 38",
            "FLIPKNIFE | Slaughter - 59",
            "FLIPKNIFE | Case Hardened - 44",
            "FLIPKNIFE | Blue Steel - 42",
            "FLIPKNIFE | Urban Masked - 143",
            "FLIPKNIFE | Night - 40",
            "FLIPKNIFE | Stained - 43",
            "FLIPKNIFE | Forest DDPAT - 5",
            "FLIPKNIFE | Safari Mesh - 72",
            "FLIPKNIFE | Boreal Forest - 77",
            "FLIPKNIFE | Scorched - 175",
            "",
            "",
            "//Gut Knife Skins",
            "",
            "GUTKNIFE | Lore - 560",
            "GUTKNIFE | Autotronic - 575",
            "GUTKNIFE | Gamma Doppler Phase 1 - 569",
            "GUTKNIFE | Gamma Doppler Phase 2 - 570",
            "GUTKNIFE | Gamma Doppler Phase 3 - 571",
            "GUTKNIFE | Gamma Doppler Phase 4 - 572",
            "GUTKNIFE | Gamma Doppler Emerald - 568",
            "GUTKNIFE | Black Laminate - 565",
            "GUTKNIFE | Freehand - 580",
            "GUTKNIFE | Bright Water - 578",
            "GUTKNIFE | Marble Fade - 413",
            "GUTKNIFE | Doppler Phase 1 - 418",
            "GUTKNIFE | Doppler Phase 2 - 419",
            "GUTKNIFE | Doppler Phase 3 - 420",
            "GUTKNIFE | Doppler Phase 4 - 421",
            "GUTKNIFE | Doppler Ruby - 415",
            "GUTKNIFE | Doppler Sapphire - 416",
            "GUTKNIFE | Doppler Black Pearl - 417",
            "GUTKNIFE | Tiger Tooth - 409",
            "GUTKNIFE | Damascus Steel - 410",
            "GUTKNIFE | Ultraviolet - 98",
            "GUTKNIFE | Rust Coat - 414",
            "GUTKNIFE | Stained - 43",
            "GUTKNIFE | Crimson Web - 12",
            "GUTKNIFE | Blue Steel - 42",
            "GUTKNIFE | Case Hardened - 44",
            "GUTKNIFE | Fade - 38",
            "GUTKNIFE | Slaughter - 59",
            "GUTKNIFE | Urban Masked - 143",
            "GUTKNIFE | Night - 40",
            "GUTKNIFE | Boreal Forest - 77",
            "GUTKNIFE | Forest DDPAT - 5",
            "GUTKNIFE | Safari Mesh - 72",
            "GUTKNIFE | Scorched - 175",
            "",
            "",
            "//Huntsman Knife Skins",
            "",
            "HUNTSMANKNIFE | Marble Fade - 413",
            "HUNTSMANKNIFE | Doppler Phase 1 - 418",
            "HUNTSMANKNIFE | Doppler Phase 2 - 419",
            "HUNTSMANKNIFE | Doppler Phase 3 - 420",
            "HUNTSMANKNIFE | Doppler Phase 4 - 421",
            "HUNTSMANKNIFE | Doppler Ruby - 415",
            "HUNTSMANKNIFE | Doppler Sapphire - 416",
            "HUNTSMANKNIFE | Doppler Black Pearl - 417",
            "HUNTSMANKNIFE | Tiger Tooth - 409",
            "HUNTSMANKNIFE | Damascus Steel - 411",
            "HUNTSMANKNIFE | Ultraviolet - 620",
            "HUNTSMANKNIFE | Rust Coat - 414",
            "HUNTSMANKNIFE | Fade - 38",
            "HUNTSMANKNIFE | Case Hardened - 44",
            "HUNTSMANKNIFE | Slaughter - 59",
            "HUNTSMANKNIFE | Crimson Web - 12",
            "HUNTSMANKNIFE | Blue Steel - 42",
            "HUNTSMANKNIFE | Night - 40",
            "HUNTSMANKNIFE | Scorched - 175",
            "HUNTSMANKNIFE | Boreal Forest - 77",
            "HUNTSMANKNIFE | Stained - 43",
            "HUNTSMANKNIFE | Safari Mesh - 72",
            "HUNTSMANKNIFE | Forest DDPAT - 5",
            "HUNTSMANKNIFE | Urban Masked - 143",
            "",
            "",
            "//Karambit Skins",
            "",
            "KARAMBIT | Lore - 561",
            "KARAMBIT | Autotronic - 576",
            "KARAMBIT | Gamma Doppler Phase 1 - 569",
            "KARAMBIT | Gamma Doppler Phase 2 - 570",
            "KARAMBIT | Gamma Doppler Phase 3 - 571",
            "KARAMBIT | Gamma Doppler Phase 4 - 572",
            "KARAMBIT | Gamma Doppler Emerald - 568",
            "KARAMBIT | Black Laminate - 566",
            "KARAMBIT | Freehand - 582",
            "KARAMBIT | Bright Water - 578",
            "KARAMBIT | Marble Fade - 413",
            "KARAMBIT | Tiger Tooth - 409",
            "KARAMBIT | Doppler Phase 1 - 418",
            "KARAMBIT | Doppler Phase 2 - 419",
            "KARAMBIT | Doppler Phase 3 - 420",
            "KARAMBIT | Doppler Phase 4 - 421",
            "KARAMBIT | Doppler Ruby - 415",
            "KARAMBIT | Doppler Sapphire - 416",
            "KARAMBIT | Doppler Black Pearl - 417",
            "KARAMBIT | Damascus Steel - 410",
            "KARAMBIT | Ultraviolet - 98",
            "KARAMBIT | Rust Coat - 414",
            "KARAMBIT | Fade - 38",
            "KARAMBIT | Slaughter - 59",
            "KARAMBIT | Case Hardened - 44",
            "KARAMBIT | Night - 40",
            "KARAMBIT | Crimson Web - 12",
            "KARAMBIT | Stained - 43",
            "KARAMBIT | Blue Steel - 42",
            "KARAMBIT | Boreal Forest - 77",
            "KARAMBIT | Safari Mesh - 72",
            "KARAMBIT | Scorched - 175",
            "KARAMBIT | Forest DDPAT - 5",
            "KARAMBIT | Urban Masked - 143",
            "",
            "",
            "//M9 Bayonet Skins",
            "",
            "M9BAYONET | Lore - 562",
            "M9BAYONET | Autotronic - 577",
            "M9BAYONET | Gamma Doppler Phase 1 - 569",
            "M9BAYONET | Gamma Doppler Phase 2 - 570",
            "M9BAYONET | Gamma Doppler Phase 3 - 571",
            "M9BAYONET | Gamma Doppler Phase 4 - 572",
            "M9BAYONET | Gamma Doppler Emerald - 568",
            "M9BAYONET | Black Laminate - 567",
            "M9BAYONET | Freehand - 581",
            "M9BAYONET | Bright Water - 579",
            "M9BAYONET | Marble Fade - 413",
            "M9BAYONET | Tiger Tooth - 409",
            "M9BAYONET | Doppler Phase 1 - 418",
            "M9BAYONET | Doppler Phase 2 - 419",
            "M9BAYONET | Doppler Phase 3 - 420",
            "M9BAYONET | Doppler Phase 4 - 421",
            "M9BAYONET | Doppler Ruby - 415",
            "M9BAYONET | Doppler Sapphire - 416",
            "M9BAYONET | Doppler Black Pearl - 417",
            "M9BAYONET | Damascus Steel - 411",
            "M9BAYONET | Rust Coat - 414",
            "M9BAYONET | Ultraviolet - 98",
            "M9BAYONET | Fade - 38",
            "M9BAYONET | Slaughter - 59",
            "M9BAYONET | Crimson Web - 12",
            "M9BAYONET | Case Hardened - 44",
            "M9BAYONET | Night - 40",
            "M9BAYONET | Blue Steel - 42",
            "M9BAYONET | Boreal Forest - 77",
            "M9BAYONET | Stained - 43",
            "M9BAYONET | Scorched - 175",
            "M9BAYONET | Urban Masked - 143",
            "M9BAYONET | Forest DDPAT - 5",
            "M9BAYONET | Safari Mesh - 72",
            "",
            "",
            "//Shadow Daggers Skins",
            "",
            "SHADOWDAGGERS | Marble Fade - 413",
            "SHADOWDAGGERS | Doppler Phase 1 - 418",
            "SHADOWDAGGERS | Doppler Phase 2 - 618",
            "SHADOWDAGGERS | Doppler Phase 3 - 420",
            "SHADOWDAGGERS | Doppler Phase 4 - 421",
            "SHADOWDAGGERS | Doppler Ruby - 415",
            "SHADOWDAGGERS | Doppler Sapphire - 619",
            "SHADOWDAGGERS | Doppler Black Pearl - 617",
            "SHADOWDAGGERS | Tiger Tooth - 409",
            "SHADOWDAGGERS | Ultraviolet - 98",
            "SHADOWDAGGERS | Damascus Steel - 411",
            "SHADOWDAGGERS | Rust Coat - 414",
            "SHADOWDAGGERS | Night - 40",
            "SHADOWDAGGERS | Fade - 38",
            "SHADOWDAGGERS | Slaughter - 59",
            "SHADOWDAGGERS | Crimson Web - 12",
            "SHADOWDAGGERS | Case Hardened - 44",
            "SHADOWDAGGERS | Blue Steel - 42",
            "SHADOWDAGGERS | Urban Masked - 143",
            "SHADOWDAGGERS | Boreal Forest - 77",
            "SHADOWDAGGERS | Scorched - 175",
            "SHADOWDAGGERS | Forest DDPAT - 5",
            "SHADOWDAGGERS | Stained - 43",
            "SHADOWDAGGERS | Safari Mesh - 72"});
            this.comboBox3.Location = new System.Drawing.Point(282, 98);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(227, 21);
            this.comboBox3.TabIndex = 15;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(208, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "GLOVES CHANGER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(24, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "MODEL GLOVE CT";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(279, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "MODEL GLOVE TR";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(27, 202);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(227, 21);
            this.comboBox4.TabIndex = 19;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(282, 202);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(227, 21);
            this.comboBox5.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(24, 241);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "SKIN GLOVE CT";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(280, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "SKIN GLOVE TR";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(27, 257);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(227, 21);
            this.comboBox6.TabIndex = 23;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(283, 257);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(227, 21);
            this.comboBox7.TabIndex = 24;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(62, 337);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 23);
            this.button1.TabIndex = 25;
            this.button1.Text = "DOWNLOAD MODELS PACK";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(309, 337);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(175, 23);
            this.button2.TabIndex = 26;
            this.button2.Text = "DOWNLOAD SKIN PACK";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textDisplay2
            // 
            this.textDisplay2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textDisplay2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textDisplay2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDisplay2.ForeColor = System.Drawing.SystemColors.Menu;
            this.textDisplay2.Location = new System.Drawing.Point(722, 28);
            this.textDisplay2.Multiline = true;
            this.textDisplay2.Name = "textDisplay2";
            this.textDisplay2.ReadOnly = true;
            this.textDisplay2.Size = new System.Drawing.Size(125, 33);
            this.textDisplay2.TabIndex = 28;
            this.textDisplay2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(742, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "TERRORISTS";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(536, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(151, 13);
            this.label10.TabIndex = 31;
            this.label10.Text = "COUNTER-TERRORISTS";
            // 
            // pictureBox2
            // 
            this.pictureBox2.InitialImage = global::ComboBox.Properties.Resources.load;
            this.pictureBox2.Location = new System.Drawing.Point(722, 58);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 83);
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.InitialImage = global::ComboBox.Properties.Resources.load;
            this.pictureBox1.Location = new System.Drawing.Point(549, 58);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 83);
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // SelectionSwitchStatement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(871, 368);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textDisplay2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.lblCountries);
            this.Controls.Add(this.cboCountries);
            this.Name = "SelectionSwitchStatement";
            this.Text = "Skin Changer by H0PP3X";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboCountries;
        private System.Windows.Forms.Label lblCountries;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textDisplay2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblPgb1;
    }
}

